output "private_ip_address" {
  value = azurerm_network_interface.this.private_ip_address
}

output "virtual_machine_id" {
  value = azurerm_linux_virtual_machine.this.id
}
